import React, { lazy, Suspense, useState, useEffect } from 'react';

// Il vecchio indirizzo #admin porta ora al link dedicato dell'app gestionale.
if (window.location.hash === '#admin') {
  window.location.replace('/admin/');
}
import { Hero } from './components/Hero';
import { Services } from './components/Services';
import { WhyChooseUs } from './components/WhyChooseUs';
import { HowItWorks } from './components/HowItWorks';
import { CtaSection } from './components/CtaSection';
import { Footer } from './components/Footer';
import { MessageSquare, ChevronUp } from 'lucide-react';

const VinHelperModal = lazy(() => import('./components/VinHelperModal').then(({ VinHelperModal }) => ({ default: VinHelperModal })));

export default function App() {
  const [selectedService, setSelectedService] = useState<string>('');
  const [isVinHelperOpen, setIsVinHelperOpen] = useState(false);
  const [showScrollTop, setShowScrollTop] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 400) {
        setShowScrollTop(true);
      } else {
        setShowScrollTop(false);
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  const openAdminView = () => {
    window.location.href = '/admin/';
  };

  const handleSelectServiceFromSection = (serviceName: string) => {
    setSelectedService(serviceName);
    const formElement = document.getElementById('preventivo');
    if (formElement) {
      formElement.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="flex flex-col min-h-screen bg-slate-50">
      {/* One-page layout: ogni sezione è una tappa naturale dello scroll */}
      <main id="contenuto-principale" className="flex-1">
        {/* Hero Section with Form */}
        <Hero
          onOpenVinHelper={() => setIsVinHelperOpen(true)}
          selectedService={selectedService}
          setSelectedService={setSelectedService}
        />

        {/* Services Section */}
        <Services onSelectService={handleSelectServiceFromSection} />

        {/* Why Choose Us Section */}
        <WhyChooseUs />

        {/* How It Works Section */}
        <HowItWorks />

        {/* Call To Action & Contact Section */}
        <CtaSection />
      </main>

      {/* Footer */}
      <Footer onOpenDashboard={openAdminView} />

      {/* Modals */}
      {isVinHelperOpen && (
        <Suspense fallback={null}>
          <VinHelperModal isOpen onClose={() => setIsVinHelperOpen(false)} />
        </Suspense>
      )}

      {/* Floating Action Controls for Mobile / Desktop */}
      <div className="fixed bottom-4 right-4 z-30 flex flex-col items-end gap-2.5">
        {/* WhatsApp Fast Floating Button */}
        <a
          href="https://wa.me/393249991990?text=Salve%20Autofficina%20Putignano,%20vorrei%20informazioni%20su%20un%20preventivo."
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-2 p-3 bg-emerald-700 hover:bg-emerald-800 text-white rounded-full shadow-xl shadow-emerald-950/60 transition-transform hover:scale-105 active:scale-95 group"
          aria-label="Contattaci su WhatsApp"
        >
          <MessageSquare className="w-5 h-5" />
          <span className="hidden sm:inline-block pr-1 text-xs font-bold">WhatsApp</span>
        </a>

        {/* Scroll To Top Button */}
        {showScrollTop && (
          <button
            onClick={scrollToTop}
            className="p-3 bg-slate-800/90 hover:bg-slate-700 text-slate-300 hover:text-white rounded-full shadow-lg border border-slate-700 transition-all cursor-pointer"
            aria-label="Torna su"
          >
            <ChevronUp className="w-5 h-5" />
          </button>
        )}
      </div>
    </div>
  );
}
