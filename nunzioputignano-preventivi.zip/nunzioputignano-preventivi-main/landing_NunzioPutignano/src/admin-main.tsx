import { createRoot } from 'react-dom/client';
import { AdminContainer } from './components/AdminContainer';
import './index.css';

const backToSite = () => {
  window.location.href = '/';
};

createRoot(document.getElementById('root')!).render(<AdminContainer onBackToSite={backToSite} />);
